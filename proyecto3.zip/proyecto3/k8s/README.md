Manifiestos generados con `kompose convert -f ../docker-compose.yml`.  
Aplícalos con:

```bash
kubectl apply -k .
```

